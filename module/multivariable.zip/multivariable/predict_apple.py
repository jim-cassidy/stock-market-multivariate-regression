import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns


# Make numpy printouts easier to read.
np.set_printoptions(precision=3, suppress=True)

import tensorflow as tf

from tensorflow import keras
from tensorflow.keras import layers
#from tensorflow.keras.layers.experimental import preprocessing

from tensorflow.keras.datasets import imdb
from tensorflow.keras import preprocessing


print(tf.__version__)

#url = 'http://archive.ics.uci.edu/ml/machine-learning-databases/auto-mpg/auto-mpg.data'
#column_names = ['MPG', 'Cylinders', 'Displacement', 'Horsepower', 'Weight',
#               'Acceleration', 'Model Year', 'Origin']

url = 'https://raw.githubusercontent.com/jim-cassidy/stock-market-multivariate-regression/main/data/apple_stock2.csv'
df = pd.read_csv(url, index_col=0)
print(df.head(5))


url = 'https://raw.githubusercontent.com/jim-cassidy/stock-market-multivariate-regression/main/data/apple_stock2.csv'

column_names = [ 'year', 'count', 'gdp-growth', 'net income' ]

raw_dataset = pd.read_csv(url, names=column_names,
                          na_values='?', comment='\t',
                          sep=' ', skipinitialspace=True)

print ( raw_dataset )

dataset = raw_dataset.copy()
dataset.tail()

dataset.isna().sum()

#dataset['Origin'] = dataset['Origin'].map({1: 'USA', 2: 'Europe', 3: 'Japan'})

dataset = pd.get_dummies(dataset, prefix='', prefix_sep='')
dataset.tail()

train_dataset = dataset.sample(frac=0.8, random_state=0)
test_dataset = dataset.drop(train_dataset.index)

train_dataset.describe().transpose()

print ( train_dataset.describe().transpose() )

train_features = train_dataset.copy()
test_features = test_dataset.copy()

train_labels = train_features.pop('gdp-growth')
test_labels = test_features.pop('gdp-growth')

print ("----")

train_dataset.describe().transpose()[['mean', 'std']]

print ( train_dataset )






